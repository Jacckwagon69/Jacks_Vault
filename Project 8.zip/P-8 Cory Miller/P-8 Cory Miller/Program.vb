Imports System

Module Program
    Sub Main(args As String())
        Dim X1, X2, Y1, Y2 As Double
        Dim M, Yint, Xm, Ym, D, T As Double
        Dim MRAD, TRAD As Double

        Console.WriteLine("
  _____           _           _      ___   
 |  __ \         (_)         | |    / _ \  
 | |__) | __ ___  _  ___  ___| |_  | (_) | 
 |  ___/ '__/ _ \| |/ _ \/ __| __|  > _ <  
 | |   | | | (_) | |  __/ (__| |_  | (_) | 
 |_|   |_|  \___/| |\___|\___|\__|  \___/  
                _/ |                       
               |__/                        ")




        Console.WriteLine("Input the X coordinate of the first point then press ENTER:")
        Console.Write("X1 =")
        X1 = Console.ReadLine()
        Console.WriteLine("Input the Y coordinate of the first point then press ENTER")
        Console.Write("Y1 =")
        Y1 = Console.ReadLine()
        Console.WriteLine("*********************************************************")
        Console.WriteLine("Input X the coordinate of the second point then press ENTER:")
        Console.Write("X2 =")
        X2 = Console.ReadLine()
        Console.WriteLine("Input the Y coordinate of the second point then press ENTER")
        Console.Write("Y2 =")
        Y2 = Console.ReadLine()

        'calculations
        D = Math.Sqrt(((X2 - X1) ^ 2) + (Y2 - Y1) ^ 2)
        Xm = (X1 + X2) / 2
        Ym = (Y1 + Y2) / 2
        M = ((Y2 - Y1) / (X2 - X1))
        TRAD = Math.Atan(M)
        T = TRAD * (180 / Math.PI)




        'output
        Console.WriteLine("First Cordinate Given:")
        Console.Write(X1)
        Console.Write(",")
        Console.Write(Y1)
        Console.WriteLine()
        Console.WriteLine("Second Cordinate Given:")
        Console.Write(X2)
        Console.Write(",")
        Console.Write(Y2)


        Console.WriteLine()
        Console.WriteLine("**********************************************************************")
        Console.WriteLine("The equation of the line:")
        If X1 = X2 Then
            Console.Write("X = (")
            Console.Write(X2)
            Console.Write(")")
            Console.WriteLine()
        End If
        If Y1 = Y2 Then
            Console.Write("Y = (")
            Console.Write(Y2)
            Console.Write(")")
            Console.WriteLine()
        End If
        If Y1 > Y2 Or Y1 < Y2 And X2 > X1 Or X2 < X1 Then
            Console.Write("Y = (")
            Console.Write(M)
            Console.Write(")X + (")
            Console.Write(Yint)
            Console.Write(")")
        End If




        Console.WriteLine()
        Console.WriteLine("********************************************************************************")
        Console.Write("The angle wrt X - axis in degree: ")
        Console.Write(Math.Round(T, 4))
        Console.WriteLine()
        Console.WriteLine("********************************************************************************")
        Console.Write("The length of line segment:")
        Console.Write(Math.Round(D, 4))
        Console.WriteLine()
        Console.WriteLine("********************************************************************************")
        Console.Write("The coordinate of midpoint: (")
        Console.Write(Xm)
        Console.Write(",")
        Console.Write(Ym)
        Console.Write(")")
        Console.WriteLine()
        Console.WriteLine("********************************************************************************")

        Console.WriteLine("Calculations Have ended")
        Console.ReadLine()
    End Sub
End Module
