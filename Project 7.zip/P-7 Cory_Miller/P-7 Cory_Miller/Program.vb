Imports System

Module Program
    Sub Main()
        Dim A1, A2, B1, B2, C1, C2, Dx, Dy, D, X, Y As Double
        Dim I, II, III As Integer


        Console.WriteLine("Input the coefficients of the first equations: A11, A12, and B1:")
        Console.WriteLine("press ENTER after each input")
        Console.WriteLine("***************************************************************")
        Console.Write("a11 =")
        A1 = Console.ReadLine()
        Console.Write("a12 = ")
        B1 = Console.ReadLine()
        Console.Write("B1 =")
        C1 = Console.ReadLine()


        Console.WriteLine("Input the coefficients of the second equations: A11, A12, and B1:")
        Console.WriteLine("press ENTER after each input")
        Console.WriteLine("***************************************************************")
        Console.Write("a11 =")
        A2 = Console.ReadLine()
        Console.Write("a12 = ")
        B2 = Console.ReadLine()
        Console.Write("B1 =")
        C2 = Console.ReadLine()

        'A1 = 3
        'B1 = -4
        'C1 = 15
        'A2 = -6
        'B2 = 1
        'C2 = -9


        Dx = ((C1 * B2) - (B1 * C2))
        D = ((A1 * B2) - (B1 * A2))
        Dy = ((A1 * C2) - (C1 * A2))

        Y = Dy / D
        X = Dx / D
        I = 0
        Console.WriteLine("Output the system of equations:")
        Console.WriteLine("******************************************************************")
        Console.Write("(")
        Console.Write(A1)
        Console.Write(")x + (")
        Console.Write(B1)
        Console.Write(")y = ")
        Console.Write(C1)
        Console.WriteLine()

        Console.Write("(")
        Console.Write(A2)
        Console.Write(")x + (")
        Console.Write(B2)
        Console.Write(")y = ")
        Console.Write(C2)
        Console.WriteLine()
        Console.WriteLine("***********************************************************")
        Console.WriteLine()
        Console.WriteLine("Output the result:")
        Console.WriteLine("***********************************************************")

        If D = 0 And Dx = 0 And Dy = 0 And I = 0 Then
            Console.WriteLine("Infinitely many solutions! ")
            Console.ReadLine()
            I += 1
        End If
        If D = 0 And Dx Or Dy = 0 And I = 0 Then
            Console.WriteLine("No Solutions! the system is inconsistent.")
            Console.ReadLine()
            I += 1
        End If

        If Dx And Dy <> 0 And I = 0 Then
            Console.WriteLine("A unique solution!")
            Console.WriteLine("The system is consitent and dependent.")
            Console.Write("X=")
            Console.Write(X)
            Console.WriteLine()
            Console.Write("Y=")
            Console.Write(Y)
            Console.WriteLine()
            Console.ReadLine()
            I += 1
        End If


    End Sub
End Module
